/**************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                                                  */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  Wu Zhongwei                                                          */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/18                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Wu Zhongwei, 2014/09/26
 *
 */

#include<stdio.h>
#include<stdlib.h>
#include"menu.h"

int Help(); 

#define CMD_MAX_LEN 128
#define DESC_LEN    1024
#define CMD_NUM     10

/*typedef a struct*/
typedef struct DataNode
{
	struct DataNode *pNext;
	char *cmd;
	char *desc;
	int (*handler)();
}tDataNode;

typedef struct LinkTable
{
	
	
}tLinkTable;


tDataNode *FindCmd(tLinkTable *head, char *cmd)
{
	tDataNode *pNode = (tDataNode *)malloc(sizeof(tDataNode));
	pNode->cmd = "";
		if(!strcmp(pNode->cmd, ""))
		{
			return pNode;
		}
	return NULL;
}
	
/*function ShowAllCmd*/	
int ShowAllCmd(tLinkTable *head)
{
	tDataNode *pNode = NULL;
	while(pNode != NULL)
	{
		
	}
	return 0;
}

/*typedef data*/
static 	tDataNode data[] = 
{
	
	
};
	
	tLinkTable *head = NULL;
	
/*function Help*/		
int Help()
{
    return 0;
}

/*function AddCmd*/	
int AddCmd()
{   
	tDataNode *p = NULL;
	
	while(p)
	{
		return 1;
	}
	return 0;
}

/*function MenuStart*/	
int MenuStart()
{
	return 0;
}

