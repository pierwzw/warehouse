/**************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                                                  */
/*                                                                                                */
/*  FILE NAME             :  menu.h                                                               */
/*  PRINCIPAL AUTHOR      :  Wu Zhongwei                                                          */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/18                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Wu Zhongwei, 2014/09/26
 *
 */

//typedef struct LinkTableNode tLinkTableNode;

typedef struct LinkTable tLinkTable;

typedef struct DataNode tDataNode;


tDataNode *FindCmd(tLinkTable *head, char *cmd);

int ShowAllCmd(tLinkTable *head);

int Help();

int AddCmd();

int MenuStart();

