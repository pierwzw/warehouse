/**************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                                                  */
/*                                                                                                */
/*  FILE NAME             :  test.c                                                               */
/*  PRINCIPAL AUTHOR      :  Wu Zhongwei                                                          */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/26                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Wu Zhongwei, 2014/09/26
 *
 */

#include<stdio.h>
#include"menu.h"

#define debug
#define FAILURE 0

int results[7] = {1,1,1,1,1,1};
char * info[7] =
{
    "test report",
    "TC1 FindCmd",
    "TC2 ShowAllCmd",
    "TC3 Help",
    "TC4 AddCmd",
    "TC5 MenuStart"
};

int main()
{
    int i;
    /*text1*/
    tDataNode *p1  = FindCmd(NULL, NULL);
    if(p1 != NULL)
    {
    	debug("TC1 Succ\n");
        results[1] = 0;      
       
    }
    else
    {
        debug("TC1 fail\n");
        results[1] = 1; 
    }
    /*text2*/
    
    int p2 = ShowAllCmd(NULL);
    if(p2 == FAILURE)
    {
        debug("TC2 Succ\n");
        results[2] = 0;       
    }
    else
    {
        debug("TC2 fail\n");
        results[2] = 1;
    }
   
    /*text3*/
    
    int p3 = Help();
    if(p3 == FAILURE)
    {
        debug("TC3 Succ\n");
        results[3] = 0;       
    }
    else
    {
        debug("TC3 fail\n");
        results[3] = 1;
    }
  
    /*text4*/
     
    int p4 = AddCmd();
  
    if(p4 == FAILURE)
    {
        debug("TC4 Succ\n");
        results[4] = 0;       
    }
    else
    {
        debug("TC4 fail\n");
        results[4] = 1;
    }
    
     /*text5*/
     
    int p5 = MenuStart();
  
    if(p5 == FAILURE)
    {
        debug("TC4 Succ\n");
        results[5] = 0;       
    }
    else
    {
        debug("TC4 fail\n");
        results[5] = 1;
    }
  

    /* test report */
    printf("test report\n");
    for(i=1;i<=5;i++)
    {
        if(results[i] == 0)
        {
            printf("Testcase Number%d F - %s\n",i,info[i]);
        }
    }
}
